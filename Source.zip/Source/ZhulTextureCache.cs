using UnityEngine;
using Verse;

namespace ZhulTribe
{
    public static class ZhulTextureCache
    {
        public static Texture2D EyeOverlayTex;
    }
}
